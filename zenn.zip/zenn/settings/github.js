module.exports = {
  githubToken: "ghp_",
  githubUser: "satridaduta74-cell"
};