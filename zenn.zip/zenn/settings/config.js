module.exports = {
  tokenBot: "8813652441:AAHg8YRbq40lwuJmjACWlVBa54_o9LfDgn8",
  ownerID: "7755583261",
  adminID: "7755583261",
};