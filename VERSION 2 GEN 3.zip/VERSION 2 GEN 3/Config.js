const global = {
    owner: [7755583261], // ganti jadi id mu
    botToken: "8813652441:AAHg8YRbq40lwuJmjACWlVBa54_o9LfDgn8", //isi make token bot mu
}

module.exports = global;